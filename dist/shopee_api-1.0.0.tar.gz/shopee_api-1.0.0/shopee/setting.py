PER_MINUTE_API_RATE = 1000

BASE_URL = "https://partner.shopeemobile.com/api/v1/"
