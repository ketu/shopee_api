a simple Python Shopee partner api client


